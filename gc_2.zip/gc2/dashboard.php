<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'includes/db.php';

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];
$username = $_SESSION['username'];

if ($user_type == 'gc_applier') {
    $stmt = $conn->prepare("SELECT plantation_size, trees_planted, gc_cost, gc_left, wallet FROM gc_appliers WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($plantation_size, $trees_planted, $gc_cost, $gc_left, $wallet);
    $stmt->fetch();
    $stmt->close();
} else {
    $stmt = $conn->prepare("SELECT construction_size, trees_cut_down, gc_required, wallet FROM gc_buyers WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($construction_size, $trees_cut_down, $gc_required, $wallet);
    $stmt->fetch();
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Green Credit Management by Ozero</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Dashboard</h1>
        <p>Welcome, <?php echo $username; ?>!</p>
        <p>Wallet Balance: $<?php echo $wallet; ?></p>

        <?php if ($user_type == 'gc_applier'): ?>
            <h2>Green Credit Applier Details</h2>
            <p>Plantation Size: <?php echo $plantation_size; ?> sq. ft.</p>
            <p>Number of Trees Planted: <?php echo $trees_planted; ?></p>
            <p>Green Credits Cost: $<?php echo $gc_cost; ?> per GC</p>
            <p>Green Credits Left: <?php echo $gc_left; ?></p>
            <a href="verify.php">Apply for Verification</a>
        <?php endif; ?>

        <?php if ($user_type == 'gc_buyer'): ?>
            <h2>Green Credit Buyer Details</h2>
            <p>Construction Size: <?php echo $construction_size; ?> sq. ft.</p>
            <p>Number of Trees Cut Down: <?php echo $trees_cut_down; ?></p>
            <p>Green Credits Required: <?php echo $gc_required; ?></p>
            <a href="trade_buyer.php">Go to Trade</a>
        <?php endif; ?>

        <a href="logout.php">Logout</a>
    </div>
</body>
</html>