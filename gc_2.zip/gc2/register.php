<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Green Credit Management by Ozero</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Register</h1>
        <p>Please select your registration type:</p>
        <div class="buttons">
            <a href="register_applier.php" class="button">Apply for GC</a>
            <a href="register_buyer.php" class="button">Buy GC</a>
        </div>
    </div>
</body>
</html>