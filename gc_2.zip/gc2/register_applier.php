<?php
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $email = $_POST['email'];
    $trees_planted = $_POST['trees_planted'];
    $gc_left = $_POST['gc_left'];
    $city = $_POST['city'];
    $plantation_size = $_POST['plantation_size'];
    $gc_cost = $_POST['gc_cost'];

    $stmt = $conn->prepare("INSERT INTO users (username, password, user_type, city, email) VALUES (?, ?, 'gc_applier', ?, ?)");
    $stmt->bind_param("ssss", $username, $password, $city, $email);
    $stmt->execute();
    $user_id = $stmt->insert_id;

    $stmt = $conn->prepare("INSERT INTO gc_appliers (user_id, plantation_size, trees_planted, gc_cost, gc_left) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiidi", $user_id, $plantation_size, $trees_planted, $gc_cost, $gc_left);
    $stmt->execute();

    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register as GC Applier - Green Credit Management by Ozero</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Register as Green Credit Applier</h1>
        <form method="post" action="register_applier.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="trees_planted">Number of Trees Planted:</label>
            <input type="number" id="trees_planted" name="trees_planted" required>
            
            <label for="gc_left">Number of Green Credits (GC) to Apply:</label>
            <input type="number" id="gc_left" name="gc_left" required>
            
            <label for="gc_cost">Cost per Green Credit:</label>
            <input type="number" step="0.01" id="gc_cost" name="gc_cost" required>
            
            <label for="city">City:</label>
            <input type="text" id="city" name="city" required>
            
            <label for="plantation_size">Plantation Size:</label>
            <input type="number" id="plantation_size" name="plantation_size" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>