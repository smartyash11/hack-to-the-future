<?php
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $email = $_POST['email'];
    $trees_cut_down = $_POST['trees_cut_down'];
    $gc_required = $_POST['gc_required'];
    $city = $_POST['city'];
    $construction_size = $_POST['construction_size'];

    $stmt = $conn->prepare("INSERT INTO users (username, password, user_type, city, email) VALUES (?, ?, 'gc_buyer', ?, ?)");
    $stmt->bind_param("ssss", $username, $password, $city, $email);
    $stmt->execute();
    $user_id = $stmt->insert_id;

    $stmt = $conn->prepare("INSERT INTO gc_buyers (user_id, construction_size, trees_cut_down, gc_required) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiii", $user_id, $construction_size, $trees_cut_down, $gc_required);
    $stmt->execute();

    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register as GC Buyer - Green Credit Management by Ozero</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Register as Green Credit Buyer</h1>
        <form method="post" action="register_buyer.php">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="trees_cut_down">Number of Trees Cut Down:</label>
            <input type="number" id="trees_cut_down" name="trees_cut_down" required>
            
            <label for="gc_required">Number of Green Credits (GC) Required:</label>
            <input type="number" id="gc_required" name="gc_required" required>
            
            <label for="city">City:</label>
            <input type="text" id="city" name="city" required>
            
            <label for="construction_size">Construction Size:</label>
            <input type="number" id="construction_size" name="construction_size" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Register</button>
        </form>
    </div>
</body>
</html>