<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'gc_applier') {
    header("Location: login.php");
    exit();
}

include 'includes/db.php';

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

$stmt = $conn->prepare("SELECT plantation_size, trees_planted, gc_cost, gc_left, wallet FROM gc_appliers WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($plantation_size, $trees_planted, $gc_cost, $gc_left, $wallet);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trade - Green Credit Applier</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Green Credit Applier Trade Page</h1>
        <p>Username: <?php echo $username; ?></p>
        <p>Wallet Balance: $<?php echo $wallet; ?></p>
        <p>Plantation Size: <?php echo $plantation_size; ?> sq. ft.</p>
        <p>Number of Trees Planted: <?php echo $trees_planted; ?></p>
        <p>Green Credits Cost: $<?php echo $gc_cost; ?> per GC</p>
        <p>Green Credits Left: <?php echo $gc_left; ?></p>
        <a href="verify.php">Apply for Verification</a>
        <a href="withdraw.php">Withdraw Money</a>
    </div>
</body>
</html>