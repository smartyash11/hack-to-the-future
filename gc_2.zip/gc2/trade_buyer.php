<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'gc_buyer') {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['city'])) {
    // Handle the case where 'city' is not set in the session
    $_SESSION['error'] = "City information missing in session. Please log in again.";
    header("Location: login.php");
    exit();
}

include 'includes/db.php';

$user_id = $_SESSION['user_id'];
$city = $_SESSION['city'];

// Initialize $buyer_wallet
$stmt = $conn->prepare("SELECT wallet FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($buyer_wallet);
$stmt->fetch();
$stmt->close();

$sql = "SELECT u.username, u.city, a.gc_cost, a.gc_left, u.id AS seller_id
        FROM gc_appliers a
        JOIN users u ON a.user_id = u.id
        WHERE u.city = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $city);
$stmt->execute();
$result = $stmt->get_result();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $seller_id = $_POST['seller_id'];
    $gc_quantity = $_POST['gc_quantity'];

    // Fetch seller details
    $stmt = $conn->prepare("SELECT gc_cost, gc_left FROM gc_appliers WHERE user_id = ?");
    $stmt->bind_param("i", $seller_id);
    $stmt->execute();
    $stmt->bind_result($gc_cost, $gc_left);
    $stmt->fetch();
    $stmt->close();

    $total_cost = $gc_quantity * $gc_cost;

    if ($gc_quantity <= $gc_left && $total_cost <= $buyer_wallet) {
        // Update seller wallet and gc_left
        $stmt = $conn->prepare("UPDATE gc_appliers SET gc_left = gc_left - ?, wallet = wallet + ? WHERE user_id = ?");
        $stmt->bind_param("idi", $gc_quantity, $total_cost, $seller_id);
        $stmt->execute();
        $stmt->close();

        // Update buyer wallet and gc_required
        $stmt = $conn->prepare("UPDATE gc_buyers SET gc_required = gc_required - ? WHERE user_id = ?");
        $stmt->bind_param("ii", $gc_quantity, $user_id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("UPDATE users SET wallet = wallet - ? WHERE id = ?");
        $stmt->bind_param("di", $total_cost, $user_id);
        $stmt->execute();
        $stmt->close();

        // Insert transaction record
        $stmt = $conn->prepare("INSERT INTO gc_transactions (buyer_id, seller_id, gc_quantity, total_cost) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiid", $user_id, $seller_id, $gc_quantity, $total_cost);
        $stmt->execute();
        $stmt->close();

        header("Location: trade_buyer.php");
        exit();
    } else {
        $error = "Insufficient GC left with seller or insufficient funds.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trade - Green Credit Buyer</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <h1>Green Credit Buyer Trade Page</h1>
        <p>Username: <?php echo $_SESSION['username']; ?></p>
        <p>Wallet Balance: $<?php echo $buyer_wallet; ?></p>
        <h2>Available Green Credits in Your City</h2>
        <?php if ($result->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Applier Username</th>
                    <th>City</th>
                    <th>GC Cost</th>
                    <th>GC Left</th>
                    <th>Buy</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['city']; ?></td>
                        <td><?php echo $row['gc_cost']; ?></td>
                        <td><?php echo $row['gc_left']; ?></td>
                        <td>
                            <form method="post" action="trade_buyer.php">
                                <input type="number" name="gc_quantity" required>
                                <input type="hidden" name="seller_id" value="<?php echo $row['seller_id']; ?>">
                                <button type="submit">Buy</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No GC owners in your city.</p>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
